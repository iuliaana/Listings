﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace SP_Gribova_11._01._22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string appPath = Application.ExecutablePath;
            // Выводим полный путь к файлу
            MessageBox.Show(appPath);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            // создаем новый процесс
            Process proc = new Process();
            // Запускаем Блокнот
            proc.StartInfo.FileName = @"Notepad.exe";
            proc.StartInfo.Arguments = "";
            proc.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            // Выводим путь к папке, откуда запущено приложение
            MessageBox.Show(System.AppDomain.CurrentDomain.BaseDirectory);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Запускаем Блокнот с файлом test.txt
            Process.Start("notepad.exe", "test.txt");
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Запускаем браузер с заданным адресом
            Process.Start("iexplore.exe", "netsources.narod.ru");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Устанавливаем информацию
            ProcessStartInfo start_info = new ProcessStartInfo
            (@"C:\windows\system32\notepad.exe");
            start_info.UseShellExecute = false;
            start_info.CreateNoWindow = true;
            // создаем новый процесс
            Process proc = new Process();
            proc.StartInfo = start_info;
            // Запускаем процесс
            proc.Start();
            // Ждем, пока Блокнот запущен
            proc.WaitForExit();
            MessageBox.Show("Код завершения: " + proc.ExitCode, "Завершение " +
            "Код", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        protected Process[] procs;
        private void button7_Click(object sender, EventArgs e)
        {
            procs = Process.GetProcessesByName("Notepad");
            int i = 0;
            while (i != procs.Length)
            {
                procs[i].Kill();
                i++;
                MessageBox.Show("Всего : " + i.ToString());
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // Получим путь к нужной папке
            string sysFolder =(@"D:\kmpo\SP\SP_Gribova_11.01.22");
            Environment.GetFolderPath(Environment.SpecialFolder.System);
            // Создадим новую структуру ProcessStartInfo
            ProcessStartInfo pInfo = new ProcessStartInfo();
            // Установим полный путь к имени файла
            pInfo.FileName = sysFolder + @"\eula.txt";
            // По умолчанию UseShellExecute равно true.
            // В данном случае указываем это поле явно для иллюстрации.
            pInfo.UseShellExecute = true;
            Process p = Process.Start(pInfo);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int am = Process.GetCurrentProcess().ProcessorAffinity.ToInt32();
            int processorCount = 0;
            while (am != 0)
            {
                processorCount++;
                am &= (am - 1);
            }
            MessageBox.Show(processorCount.ToString());
        }

        private void button10_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
 String.Format(
 "Число процессоров: {0}",
 Environment.ProcessorCount.ToString()));
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // Делаем паузу на 3 секунды
            System.Threading.Thread.Sleep(3000);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            foreach (Process p in Process.GetProcesses())
                listBox1.Items.Add(p.ToString());
        }

        private void button13_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (Process p in
            Process.GetProcesses(System.Environment.MachineName))
            {
                if (p.MainWindowHandle != IntPtr.Zero)
                {
                    // Оконные приложения
                    listBox1.Items.Add(p.ToString());
                }
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            // Очистим список
            listBox1.Items.Clear();
            // Получим список процессов, связанных с Internet Explorer
            foreach (Process p in Process.GetProcessesByName("iexplore"))
                listBox1.Items.Add(p.ToString());
        }

        private void button15_Click(object sender, EventArgs e)
        {
            // Очистим список
            listBox1.Items.Clear();
            // Получим список процессов notepad на удаленной машине skynet
            foreach (Process p in Process.GetProcessesByName("notepad",
            "skynet"))
                listBox1.Items.Add(p.ToString());
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            process.StartInfo.FileName ="mailto:email@address1.com,email@address2.com?subject=Hello& cc = email@address3.com & bcc = email@address4.com & body = Happy New Year";
process.Start();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            OperatingSystem os = Environment.OSVersion;
            listBox1.Items.Add(os.Version);
            listBox1.Items.Add(os.Platform);
            listBox1.Items.Add(os.ServicePack);
            listBox1.Items.Add(os.VersionString);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            OperatingSystem os = Environment.OSVersion;
            Version version = os.Version;
            if ((version.Major == 5) && (version.Minor == 1)
            || version.Major >= 6)
            {
                MessageBox.Show("Программа может запускаться" +
                " в вашей операционной системе");
            }
            else
            {
                MessageBox.Show
                ("Эта версия операционной системы не поддерживается." +
                "\r\n Используйте Windows XP или Windows Vista");
            }
            
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
            this.Hide();
        }
    }
}
