﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace SP_Gribova_11._01._22
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            [DllImport("mscoree.dll")]
            private static extern void GetCORSystemDirectory(
            [MarshalAs(UnmanagedType.LPTStr)]
 System.Text.StringBuilder Buffer,
            int BufferLength, ref int Length);
            [STAThread]
        }
    }
}
